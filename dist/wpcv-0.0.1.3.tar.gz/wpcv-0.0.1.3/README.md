# wpcv
A light yet powerful computer vision tookit. 

### Functions
![cannot show image](info/imgs/functions.png)