wpcv
---
A light yet powerful computer vision tookit. 