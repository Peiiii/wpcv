#wpcv
A light yet powerful computer vision tookit. 

### Functions
![cannot show image](data/imgs/functions.png)